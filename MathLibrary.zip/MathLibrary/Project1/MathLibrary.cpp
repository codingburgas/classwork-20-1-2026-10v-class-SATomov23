#include "MathLibrary.h"
int P(int a, int b, int c)
{
    return a + b + c;
}

int S(int a, int Ha)
{
    return (a * Ha) / 2;
}